function goto(url) {
    document.location.href = url;
}